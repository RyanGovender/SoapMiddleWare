﻿using System;
using Microsoft.AspNetCore.Http;
using System.ServiceModel.Channels;
using CustomSOAPMiddleware.Descriptions;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Reflection;
using CustomSOAPMiddleware.Implementation;

namespace CustomSOAPMiddleware
{
    public class SOAPEndpointMiddleware
    {
        private readonly RequestDelegate _next;
       // private readonly Type _serviceType;
        private readonly string _endpoint;
        private readonly MessageEncoder _messageEncoder;
        private readonly ServiceDescription _service;

        public SOAPEndpointMiddleware(RequestDelegate next, Type serviceType, string path, MessageEncoder messageEncoder)
        {
            _next = next;
            //_serviceType = serviceType;
            _endpoint = path;
            _messageEncoder = messageEncoder;
            _service = new ServiceDescription(serviceType);
        }

        public async Task Invoke(HttpContext httpContext, IServiceProvider serviceProvider)
        {
            DataHolder.Data.Add(httpContext.Request.Path);
            DataHolder.Data.Add(httpContext.Request.Host);
            DataHolder.Data.Add(httpContext.Request.Headers.FirstOrDefault().Value);


            if (httpContext.Request.Path.Equals(_endpoint, StringComparison.Ordinal))
            {
                Console.WriteLine($"Request for {httpContext.Request.Path} recived ({httpContext.Request.ContentLength ?? 0} bytes)");
                
                Message responseMessage;

                var requestMessage = _messageEncoder.ReadMessage(httpContext.Request.Body, 0x10000, httpContext.Request.ContentType);

                DataHolder.Data.Add(requestMessage.ToString());

                var soapAction = httpContext.Request.Headers["SOAPAction"].ToString().Trim('\"');

                if (!string.IsNullOrEmpty(soapAction))
                {
                    requestMessage.Headers.Action = soapAction;
                }

                var operation = _service.Operations
                    .Where(o => o.SoapAction.Equals(requestMessage.Headers.Action, StringComparison.Ordinal)).FirstOrDefault();

                if(operation == null)
                {
                    throw new InvalidOperationException($"No Operation for specified action : {requestMessage.Headers.Action}");
                }

                var serviceInstance = serviceProvider.GetService(_service.ServiceType);

                var arguments = GetRequestArguments(requestMessage, operation);

                var responseObject = operation.DispatchMethod.Invoke(serviceInstance, arguments.ToArray());

                var resultName = operation.DispatchMethod.ReturnParameter.GetCustomAttribute<MessageParameterAttribute>()?
                    .Name ?? operation.Name + "Result";

                var bodyWriter = new ServiceBodyWriter(operation.Contract.Namespace, operation.Name + "Response", resultName, responseObject);

                responseMessage = Message.CreateMessage(_messageEncoder.MessageVersion, operation.ReplyAction, bodyWriter);

                httpContext.Response.ContentType = httpContext.Request.ContentType;

                httpContext.Response.Headers["SOAPAction"] = responseMessage.Headers.Action;

                _messageEncoder.WriteMessage(responseMessage, httpContext.Response.Body);
            }
            else
            {
                await _next(httpContext);
            }
        }

        private object[] GetRequestArguments(Message requestMessage, OperationsDescription operation)
        {
            var parameters = operation.DispatchMethod.GetParameters();
            var arguments = new List<object>();

            // Deserialize request wrapper and object
            using (var xmlReader = requestMessage.GetReaderAtBodyContents())
            {
                // Find the element for the operation's data
                xmlReader.ReadStartElement(operation.Name, operation.Contract.Namespace);

                for (int i = 0; i < parameters.Length; i++)
                {
                    var parameterName = parameters[i].GetCustomAttribute<MessageParameterAttribute>()?.Name ?? parameters[i].Name;
                    xmlReader.MoveToStartElement(parameterName, operation.Contract.Namespace);
                    if (xmlReader.IsStartElement(parameterName, operation.Contract.Namespace))
                    {
                        var serializer = new DataContractSerializer(parameters[i].ParameterType, parameterName, operation.Contract.Namespace);
                        arguments.Add(serializer.ReadObject(xmlReader, verifyObjectName: true));
                    }
                }
            }

            return arguments.ToArray();
        }
    }
}

