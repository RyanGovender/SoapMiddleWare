﻿namespace CustomSOAPMiddleware;
public class Class1
{

}

