﻿using System;
using System.Reflection;
using System.ServiceModel;

namespace CustomSOAPMiddleware.Descriptions
{
    public class ContractsDescription
    {
        public ServiceDescription Service { get; private set; }
        public string Name { get; private set; }
        public string Namespace { get; private set; }
        public Type ContractType { get; private set; }
        public IEnumerable<OperationsDescription> Operations { get; private set; }

        public ContractsDescription(ServiceDescription service, Type contractType, ServiceContractAttribute attribute)
        {
            Service = service;
            ContractType = contractType;
            Namespace = attribute.Namespace ?? "http://tempuri.org/"; // Namespace defaults to http://tempuri.org/
            Name = attribute.Name ?? ContractType.Name; // Name defaults to the type name

            var operations = new List<OperationsDescription>();
            foreach (var operationMethodInfo in ContractType.GetTypeInfo().DeclaredMethods)
            {
                foreach (var operationContract in operationMethodInfo.GetCustomAttributes<OperationContractAttribute>())
                {
                    operations.Add(new OperationsDescription(this, operationMethodInfo, operationContract));
                }
            }
            Operations = operations;
        }
    }
}

