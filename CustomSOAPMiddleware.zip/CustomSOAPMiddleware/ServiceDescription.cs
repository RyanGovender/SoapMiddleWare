﻿using System;
using System.Reflection;
using System.ServiceModel;
using CustomSOAPMiddleware.Descriptions;

namespace CustomSOAPMiddleware
{
    public class ServiceDescription
    {
        public Type ServiceType { get; set; }
        public IEnumerable<ContractsDescription> Contracts { get; set; }
        public IEnumerable<OperationsDescription> Operations => Contracts.SelectMany(c => c.Operations);

        public ServiceDescription(Type serviceType)
        {
           ServiceType = serviceType;

            var contracts = new List<ContractsDescription>();

            foreach(var contractType in ServiceType.GetInterfaces())
            {
                foreach(var serviceContract in contractType.GetTypeInfo().GetCustomAttributes<ServiceContractAttribute>())
                {
                    contracts.Add(new ContractsDescription(this, contractType, serviceContract));
                }
            }

            Contracts = contracts;
        }
    }
}

