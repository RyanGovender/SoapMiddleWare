﻿using System;
namespace CustomSOAPMiddleware
{
    public static  class DataHolder
    {
        public static List<dynamic> Data = new List<dynamic>();
    }
}

